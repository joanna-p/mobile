package com.cg.mobiles.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;

import org.junit.jupiter.api.Test;


class TestMobiles {

	static MobileDao mobiledao = null;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		mobiledao = new MobileDaoImp();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		mobiledao = null;
	}


	@Test
	void test() {
		fail("Not yet implemented");
	}

}
