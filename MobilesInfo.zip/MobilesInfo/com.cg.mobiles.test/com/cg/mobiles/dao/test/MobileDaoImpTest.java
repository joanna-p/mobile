package com.cg.mobiles.dao.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.mobiles.Exceptions.MobileException;
import com.cg.mobiles.dao.MobileDao;
import com.cg.mobiles.dao.MobileDaoImp;
import com.cg.mobiles.model.MobileTableModel;
import com.cg.mobiles.model.MobilesModel;

class MobileDaoImpTest {

	MobileDao mobiledao=null;
	
	@BeforeEach
	void setUp() throws Exception {
		mobiledao=new MobileDaoImp();
		
	}

	@AfterEach
	void tearDown() throws Exception {
		mobiledao=null;
	}

	@Test
	void testInsertion() {
		int variable=0;
		MobilesModel mobilesMain = new MobilesModel();
		mobilesMain.setCustomername("Joanna Pranathi");
		mobilesMain.setMailid("joanna@gmail.com");
		mobilesMain.setPhoneno(9701521771l);
		mobilesMain.setMobileid(1002);
		try {
			variable = mobiledao.insertion(mobilesMain);
		} catch (MobileException e) {
			e.printStackTrace();
		}
		assertEquals(1, variable);

	}

	@Test
	void testViewRange() {
		List<MobileTableModel> mobilelist = null;
		Double range1 =  5000d;
		Double range2 =  15000d;
		try {
			mobilelist = mobiledao.viewRange(range1,range2);
		} catch (MobileException e) {
			
			e.printStackTrace();
		}
		assertEquals(1, mobilelist.size());
	}

}
