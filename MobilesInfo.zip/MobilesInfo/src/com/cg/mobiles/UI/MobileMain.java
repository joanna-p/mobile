package com.cg.mobiles.UI;

import java.util.List;
import java.util.Scanner;

import com.cg.mobiles.Exceptions.MobileException;
import com.cg.mobiles.model.MobileTableModel;
import com.cg.mobiles.model.MobilesModel;
import com.cg.mobiles.service.MobileService;
import com.cg.mobiles.service.MobileServiceImp;

public class MobileMain {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		
		MobilesModel mobilesMain = new MobilesModel();
		List<MobileTableModel> mobilelist = null;

		System.out.println("1 - purchasing");
		System.out.println("2 - View all the mobiles");
		System.out.println("3 - Delete mobile details based on mobileid");
		System.out.println("4 - Search mobile based on price range");
		System.out.println("Enter your choice");
		int choice = scanner.nextInt();
		scanner.nextLine();
		switch (choice) {
		case 1:

			System.out.println("Enter the customer name");
			String customername = scanner.nextLine();
			System.out.println("Enter the mail id ");
			String mailid = scanner.nextLine();
			System.out.println("Enter the phone number ");
			Long phoneno = scanner.nextLong();
			System.out.println("Enter the mobile id ");
			int mobileid = scanner.nextInt();

			mobilesMain.setCustomername(customername);
			mobilesMain.setMailid(mailid);
			mobilesMain.setPhoneno(phoneno);
			mobilesMain.setMobileid(mobileid);

			MobileService mobileService = new MobileServiceImp();

			try {

				boolean result = mobileService.insertdetails(mobilesMain);

				if (result) {
					int variable = mobileService.insertion(mobilesMain);
					System.out.println(variable + " rows inserted");
				}

			} catch (MobileException e) {
				System.err.println(e.getMessage());

			}
			break;

		case 2:
			MobileService mobileService1 = new MobileServiceImp();
			try {
				
				mobilelist = mobileService1.viewTable();
				if(mobilelist.isEmpty())
				{
					System.out.println("No records found");
				}else {
				for (MobileTableModel mobileTableModel : mobilelist) {
					System.out.println(mobileTableModel.getMobileid() + "---" + mobileTableModel.getName() + "---"
							+ mobileTableModel.getPrice() + "---" + mobileTableModel.getQuantity());
				}}

			} catch (Exception e) {
				System.out.println(" No records ");
			}

			break;
		case 3:
			
			MobileService mobileService2 =  new MobileServiceImp();
			int deletedetails = scanner.nextInt();
			
			
			int result=0;
			try {
				
				result= mobileService2.delete(deletedetails);
				System.out.println(result+" deleted");
			} catch (MobileException e) {
				System.out.println(" cannot delete");
			}

			
			break;
			
			
		case 4:
			MobileService mobileService3 = new MobileServiceImp();
			Double range1 =  scanner.nextDouble();
			Double range2 = scanner.nextDouble();
			
			try {
				mobilelist = mobileService3.viewRange(range1,range2);
				if(mobilelist.isEmpty())
				{
					System.out.println("No records found");
				}else {
					System.out.println("Mobile Details :");
					for(MobileTableModel mobileTableModel : mobilelist)
						System.out.println(mobileTableModel.getName()+ "----"+mobileTableModel.getPrice());
					
				}
			} catch (MobileException e) {
				System.out.println("No records");
			}
			
			break;

		default:
			break;
		}

		scanner.close();
	}
}
