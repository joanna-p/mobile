package com.cg.mobiles.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cg.mobiles.Exceptions.MobileException;
import com.cg.mobiles.dao.MobileDao;
import com.cg.mobiles.dao.MobileDaoImp;
import com.cg.mobiles.model.MobileTableModel;
import com.cg.mobiles.model.MobilesModel;

public class MobileServiceImp implements MobileService {

	List<String> list = new ArrayList<>();
	MobileDao mobileDao = new MobileDaoImp();
	static Logger logger = Logger.getLogger(MobileServiceImp.class);
	@Override
	public boolean insertdetails(MobilesModel mobilesModel) throws MobileException {

		boolean validateFlag = false;
	
		if (!checkName(mobilesModel.getCustomername())) {
			logger.info("in if block");
			list.add("Name must start with capital letter and the length should be in between 5 to 20 \n");
		}
		if (!checkMailid(mobilesModel.getMailid())) {
			logger.info("in if block");
			list.add("should contain lowercase, uppercase, special character and etc \n");
		}
		if (!checkPhonenumber(mobilesModel.getPhoneno())) {
			logger.info("in if block");
			list.add("phone number should contain exactly 10 digits and must start with 6|7|8|9 \n");
		}
		if (!checkMobileid(mobilesModel.getMobileid())) {
			logger.info("in if block");
			list.add("mobile id should contain exactly 4 digits only \n");
		}
		if (!list.isEmpty()) {
			logger.info("in if block");
			System.out.println(list + "");
		} else {
			logger.info("in else block");
			validateFlag = true;
		}
		return validateFlag;
	}

	public boolean checkName(String customername) {
		logger.info("in checkName block");
		String nameRegEx = "[A-Z]{1}[A-Za-z\\s]{2,19}$";
		return Pattern.matches(nameRegEx, customername);
	}

	public boolean checkMailid(String mailid) {
		logger.info("in checkMailid block");
		String mailRegEx = "[a-zA-Z._]*@[A-Za-z]*\\.[a-z]*";
		return Pattern.matches(mailRegEx, mailid);
	}

	public boolean checkPhonenumber(Long phoneno) {
		logger.info("in checkPhonenumber block");
		String phoneRegEx = "[6|7|8|9]{1}[0-9]{9}";
		return Pattern.matches(phoneRegEx, String.valueOf(phoneno));
	}

	public boolean checkMobileid(int mobileid) {
		logger.info("in checkMobileid block");
			String mobileRegEx = "[0-9]{4}";
			return Pattern.matches(mobileRegEx, String.valueOf(mobileid));
	}

	@Override
	public int insertion(MobilesModel mobilesMain) throws MobileException {
		logger.info("in insertion block");
		return mobileDao.insertion(mobilesMain);
	}

	@Override
	public List<MobileTableModel> viewTable() throws MobileException {
		
		logger.info("in viewing the table block");
		
		return mobileDao.viewTable();
	}

	@Override
	public int delete(int deletedetails) throws MobileException {
		
		logger.info("in deleting a record block");
		return mobileDao.delete(deletedetails);
	}


	

	@Override
	public List<MobileTableModel> viewRange(Double range1, Double range2) throws MobileException {
		
		logger.info("in price range block");
		return mobileDao.viewRange(range1, range2);
	}

	


}
