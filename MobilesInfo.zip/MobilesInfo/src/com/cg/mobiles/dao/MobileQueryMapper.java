package com.cg.mobiles.dao;

public interface MobileQueryMapper {

	public static final String selectQuery= "select * from mobiles";
	public static final String insertQuery = "insert into purchasedetails values(purchaseid_sequence.nextval,?,?,?,sysdate,?)";
	public static final String updateQuery ="update mobiles set quantity=quantity-1 where mobileid=?";
	public static final String deleteQuery = "delete from mobiles where mobileid=?";
	public static final String rangeQuery = "select name,price from mobiles where price between ? and ?";
}
