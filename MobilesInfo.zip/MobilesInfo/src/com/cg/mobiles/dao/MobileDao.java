package com.cg.mobiles.dao;

import java.util.List;

import com.cg.mobiles.Exceptions.MobileException;
import com.cg.mobiles.model.MobileTableModel;
import com.cg.mobiles.model.MobilesModel;

public interface MobileDao {



	int insertion(MobilesModel mobilesMain) throws MobileException;

	List<MobileTableModel> viewTable() throws MobileException;

	int delete(int deletedetails) throws MobileException;

	

	List<MobileTableModel> viewRange(Double range1, Double range2) throws MobileException;

}
