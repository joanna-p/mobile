package com.cg.mobiles.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.mobiles.Exceptions.MobileException;
import com.cg.mobiles.Utility.JdbcConnection;

import com.cg.mobiles.model.MobileTableModel;
import com.cg.mobiles.model.MobilesModel;


public class MobileDaoImp implements MobileDao {

	Connection connection = null;
	PreparedStatement statement = null;
	Statement stmt = null;
	int result = 0;
	int result1 = 0;
	int result3 = 0;
	ResultSet resultSet = null;
	static Logger logger = Logger.getLogger(MobileDaoImp.class);

	@Override
	public int insertion(MobilesModel mobilesMain) throws MobileException {

		connection = JdbcConnection.getConnection();

		try {
			logger.info("in try block");
			statement = connection.prepareStatement(MobileQueryMapper.selectQuery);

			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				logger.info("in while block");
				Integer mobileid1 = resultSet.getInt("mobileid");

				if (mobileid1.equals(mobilesMain.getMobileid())) {
					logger.info("in if block");
					Integer quantity1 = resultSet.getInt("quantity");

					if (quantity1 > 0) {
						logger.info("in if block");
						statement = connection.prepareStatement(MobileQueryMapper.updateQuery);
						statement.setInt(1, mobileid1);
						result1 = statement.executeUpdate();

						statement = connection.prepareStatement(MobileQueryMapper.insertQuery);
						statement.setString(1, mobilesMain.getCustomername());
						statement.setString(2, mobilesMain.getMailid());
						statement.setLong(3, mobilesMain.getPhoneno());
						statement.setInt(4, mobilesMain.getMobileid());

						result = statement.executeUpdate();
						System.out.println("Row added");

					}

				}
			}

		} catch (SQLException e) {
			logger.info("in catch block");
			System.out.println("Not connected");

		} finally {
			logger.info("in finally block");
			try {
				logger.info("in try block");
				resultSet.close();
			} catch (SQLException e1) {
				logger.info("in catch block");
				throw new MobileException("ResultSet not closed");
			}

			try {
				logger.info("in try block");
				statement.close();
			} catch (SQLException e) {
				logger.info("in catch block");
				throw new MobileException("statement not closed");
			}
			try {
				logger.info("in try block");
				connection.close();
			} catch (SQLException e) {
				logger.info("in catch block");
				throw new MobileException("connection not closed");
			}
		}
		return result;

	}

	@Override
	public List<MobileTableModel> viewTable() throws MobileException {

		connection = JdbcConnection.getConnection();
		List<MobileTableModel> mobilelist = new ArrayList<>();
		try {
			logger.info("in try block");
			stmt = connection.createStatement();
			resultSet = stmt.executeQuery(MobileQueryMapper.selectQuery);

			while (resultSet.next()) {
				logger.info("in while block");
				MobileTableModel mobileTableModel = new MobileTableModel();
				int mobileid = resultSet.getInt("mobileid");
				String name = resultSet.getString("name");
				Double price = resultSet.getDouble("price");
				int quantity = resultSet.getInt("quantity");

				mobileTableModel.setMobileid(mobileid);
				mobileTableModel.setName(name);
				mobileTableModel.setPrice(price);
				mobileTableModel.setQuantity(quantity);

				mobilelist.add(mobileTableModel);

			}

		} catch (SQLException e) {
			logger.info("in catch block");
			System.out.println("not inserted");
		} finally {
			logger.info("in finally block");
			try {
				logger.info("in try block");
				resultSet.close();
			} catch (SQLException e) {
				logger.info("in catch block");
				throw new MobileException("ResultSet not closed");
			}
			try {
				logger.info("in try block");
				stmt.close();
			} catch (SQLException e) {
				logger.info("in catch block");
				throw new MobileException("statement not closed");
			}
			try {
				logger.info("in try block");
				connection.close();
			} catch (SQLException e) {
				logger.info("in catch block");
				throw new MobileException("connection not closed");
			}

		}
		return mobilelist;
	}

	@Override
	public int delete(int deletedetails) throws MobileException {
		int result = 0;
		connection = JdbcConnection.getConnection();

		try {
			logger.info("in try block");
			statement = connection.prepareStatement(MobileQueryMapper.deleteQuery);
			statement.setInt(1, deletedetails);
			result = statement.executeUpdate();
			result1 = statement.executeUpdate();

		} catch (SQLException e) {
			logger.info("in catch block");
			System.out.println("handled");
		} finally {
			logger.info("in finally block");
			try {
				logger.info("in try block");
				statement.close();
			} catch (SQLException e) {
				logger.info("in catch block");
				throw new MobileException("Statement not closed");
			}
			try {
				logger.info("in try block");
				connection.close();
			} catch (SQLException e) {
				logger.info("in catch block");
				throw new MobileException("Connection not closed");
			}
		}

		return result;
	}

	@Override
	public List<MobileTableModel> viewRange(Double range1, Double range2) throws MobileException {

		connection = JdbcConnection.getConnection();
		List<MobileTableModel> mobilelist = new ArrayList<>();
		try {
			logger.info("in try block");
			statement = connection.prepareStatement(MobileQueryMapper.rangeQuery);
			statement.setDouble(1, range1);
			statement.setDouble(2, range2);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				logger.info("in while block");
				String name = resultSet.getString(1);
				Double price = resultSet.getDouble(2);
				MobileTableModel mobileTableModel = new MobileTableModel();
				mobileTableModel.setName(name);
				mobileTableModel.setPrice(price);
				mobilelist.add(mobileTableModel);

			}
		} catch (SQLException e) {
			logger.info("in catch block");
			throw new MobileException("No records Found");
		}

		return mobilelist;
	}

}
