package com.cg.mobiles.Utility;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.mobiles.Exceptions.MobileException;

public class JdbcConnection {

	private static Connection connection =null;
	static File file = null;
	static FileInputStream fileInputStream = null;
	
	public static Connection getConnection() throws MobileException{
		Properties properties=new Properties();
		file = new File("resource/Jdbc.properties");
		try {
			fileInputStream=new FileInputStream(file);
		} catch (FileNotFoundException e1) {
			
			System.out.println("File not found");
		}
		try {
			properties.load(fileInputStream);
		} catch (IOException e1) {
			
			System.out.println(e1.getMessage());
		}
		String driver = properties.getProperty("db.driver");
		String url = properties.getProperty("db.url");
		String username = properties.getProperty("db.username");
		String password = properties.getProperty("db.password");
		
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			System.out.println("Class is not found");
		}
		try {
			connection = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			System.out.println("Not Connected");
		}
		
		return connection;
		
	}
	
}
