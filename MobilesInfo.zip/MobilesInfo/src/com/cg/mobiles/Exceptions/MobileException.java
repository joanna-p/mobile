package com.cg.mobiles.Exceptions;

public class MobileException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3013277994724039363L;

	public MobileException(String message) {
		super(message);
		
	}

}
