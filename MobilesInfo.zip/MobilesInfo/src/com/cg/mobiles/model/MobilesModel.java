package com.cg.mobiles.model;

import java.time.LocalDate;

public class MobilesModel {

private String customername;	
	private String mailid;
	private long phoneno;
	private LocalDate purchasedate;
	private int mobileid;
	
	
	public MobilesModel() {
		super();
		
	}
	
	public MobilesModel(String customername, String mailid, long phoneno, LocalDate purchasedate, int mobileid) {
		super();
		this.customername = customername;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.purchasedate = purchasedate;
		this.mobileid = mobileid;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public long getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}

	public LocalDate getPurchasedate() {
		return purchasedate;
	}

	public void setPurchasedate(LocalDate purchasedate) {
		this.purchasedate = purchasedate;
	}

	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}

	@Override
	public String toString() {
		return "MobilesModel [customername=" + customername + ", mailid=" + mailid + ", phoneno=" + phoneno
				+ ", purchasedate=" + purchasedate + ", mobileid=" + mobileid + "]";
	}
	
	
	
	
}
